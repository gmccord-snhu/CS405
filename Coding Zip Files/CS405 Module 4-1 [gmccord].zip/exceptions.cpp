/*****************************************************************************************
 *  File Name:    exceptions.cpp
 *  Author:       Grant McCord
 *  Course:       CS 405 � Secure Coding / Software Security
 *  Instructor:   Professor Mike Prasad
 *  Assignment:   Exception Handling
 *  Date:         March 14, 2026
 *
 *  Description:
 *  Demonstrates basic exception handling in C++, including standard exceptions,
 *  custom exceptions, and safe error handling for divide-by-zero operations.
 *****************************************************************************************/

#include <iostream>
#include <exception>
#include <stdexcept>

 // Custom exception
 // It inherits from std::exception but can be caught seperately 
class CustomException : public std::exception
{
public:
    const char* what() const noexcept override
    {
        return "Custom exception: problem in application.";
    }
};

bool do_even_more_custom_application_logic()
{
    // TODO: Throw any standard exception

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    // Throws a standard C++ exception 
    throw std::runtime_error("Standard exception: Throwing standard exception");

    // This return is never reached because the exception above
    // stops normal execution and transfers control to a catch block.
    return true;
}

void do_custom_application_logic()
{
    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing
    std::cout << "Running Custom Application Logic." << std::endl;

    try
    {
        // The intent here is to call the deeper logic safely.
        // If that function throws a standard exception, handle it here
        // so the program can recover and continue instead of terminating.
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    // Catch standard exception
    catch (const std::exception& ex)
    {
        // After catching the exception, execution continues.
        std::cout << "Caught std::exception in do_custom_application_logic: "
            << ex.what() << std::endl;
    }

    // TODO: Throw a custom exception derived from std::exception
    //  and catch it explictly in main

    // This custom exception which allows main() to catch it separately 
    // and show that custom exception types can be handled differently 
    // from standard ones.
    throw CustomException();

    // This line is not reached because the custom exception is thrown first.
    std::cout << "Leaving Custom Application Logic." << std::endl;
}

float divide(float num, float den)
{
    // TODO: Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception

    // Division by zero is a logic error; the function throws a
    // standard exception instead of allowing unsafe behavior.
	// There are different exception types which could be returned
	// runtime_error seems most apropriate in this case.
    if (den == 0.0f)
    {
        throw std::runtime_error("divide() exception: cannot divide by zero");
    }

    return (num / den);
}

void do_division() noexcept
{
    //  TODO: create an exception handler to capture ONLY the exception thrown
    //  by divide.

    float numerator = 10.0f;
    float denominator = 0;

    try
    {
        // The intent here is to test the divide() function with a value
        // that will fail, proving that the exception is thrown and handled correctly.
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::runtime_error& ex)
    {
        // This catches only the specific standard exception type used by divide().
        std::cout << "do_division() exception: " << ex.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    // TODO: Create exception handlers that catch (in this order):
    //  your custom exception
    //  std::exception
    //  uncaught exception
    //  that wraps the whole main function, and displays a message to the console.
    try
    {
        // Wrap in try-catch to implement tiered exception handling
        do_division();
        do_custom_application_logic();
    }
    // CustomException
    catch (const CustomException& ex)
    {
        // This catch comes first because CustomException inherits from std::exception.
        std::cout << "Caught custom exception in main: " << ex.what() << std::endl;
    }
    // std::exception
    catch (const std::exception& ex)
    {
        // This catch handles other standard exceptions that were not caught earlier.
        std::cout << "Caught standard exception in main: " << ex.what() << std::endl;
    }
    // anything else (uncaught exception)
    catch (...)
    {
        // This is the final catch for anything unexpected that does
        // not match the earlier handlers. Will prevent the program from crashing
        // without any message to the user.
        std::cout << "Caught an unknown exception in main." << std::endl;
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu