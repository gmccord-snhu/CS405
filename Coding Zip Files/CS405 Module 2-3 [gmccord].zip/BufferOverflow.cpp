/*****************************************************************************************
*  File Name:    BufferOverflow.cpp
*  Author:       Grant McCord
*  Course:       CS 405 � Secure Coding / Software Security
*  Instructor:   Professor Mike Prasad
*  Assignment:   Buffer Overflow Prevention
*  Date:         3/14/2026
*
*  Description:
*  This program demonstrates a buffer overflow vulnerability and how to prevent it.
*  The program prompts the user for input, but ensures the input does not exceed
*  the allocated buffer size. The constant 'account_number' is maintained in its
*  original position in memory, and the user is notified if their input is too long.
*****************************************************************************************/

#include <iomanip>
#include <iostream>

int main()
{
  std::cout << "Buffer Overflow Example" << std::endl;

  // TODO: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced -
  //  even though it is a constant and the compiler buffer overflow checks are on.
  //  You need to modify this method to prevent buffer overflow without changing the account_number
  //  variable, and its position in the declaration. It must always be directly before the variable used for input.
  //  You must notify the user if they entered too much data.

  const std::string account_number = "CharlieBrown42";
  const int MAX_INPUT = 20;
  char user_input[MAX_INPUT];

  std::cout << "Enter a value:";

  // Read in MAX_INPUT characters 
  std::cin.getline(user_input, MAX_INPUT);

  // Detect if the user typed more characters than the buffer can hold
  if (std::cin.fail()) {

      // clear the fail state
      std::cin.clear();

      // remove remaining characters from the input buffer
      std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

      // print message to user
      std::cout << "Warning: Input too long. Only the first "
          << MAX_INPUT- 1 << " characters were accepted." << std::endl;
  }

  std::cout << "You entered: " << user_input << std::endl;
  std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
