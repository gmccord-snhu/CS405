/*****************************************************************************************
 *  File Name:    Encryption.cpp
 *  Author:       Grant McCord
 *  Course:       CS 405 � Secure Coding / Software Security
 *  Instructor:   Professor Mike Prasad
 *  Assignment:   Encryption Activity
 *  Date:         April 4, 2026
 *
 *  Description:
 *  This program reads a text file, encrypts it using XOR with a password key,
 *  and writes the encrypted data to a file. It then decrypts the data using
 *  the same key and saves the result. This demonstrates basic encryption,
 *  file input/output, and string processing in C++.
 *****************************************************************************************/

 // Encryption.cpp : This file contains the 'main' function. Program execution begins and ends there.
 //
#include <cassert>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <ctime>

/// <summary>
/// encrypt or decrypt a source string using the provided key
/// </summary>
/// <param name="source">input string to process</param>
/// <param name="key">key to use in encryption / decryption</param>
/// <returns>transformed string</returns>
std::string encrypt_decrypt(const std::string& source, const std::string& key)
{
    // Store lengths to avoid recalculating them in the loop
    const auto key_length = key.length();
    const auto source_length = source.length();

    // Basic validation � key must not be empty or XOR won't work
    assert(key_length > 0);

    // Create output string initialized with source data
    std::string output = source;

    // Loop through each character in the source string
    for (size_t i = 0; i < source_length; ++i)
    {
        /*
         * XOR (exclusive OR) is a bitwise operation.
         * It compares two bits and returns:
         *   1 if the bits are different
         *   0 if the bits are the same
         *
         * Truth table:
         *   0 ^ 0 = 0
         *   1 ^ 1 = 0
         *   0 ^ 1 = 1
         *   1 ^ 0 = 1
         *
         * When applied to characters, XOR works on their ASCII values
         * at the binary level.
         *
         * Example:
         *   'A' = 01000001
         *   'K' = 01001011
         *   ----------------
         *   XOR = 00001010  (resulting encrypted character)
         *
         * This "scrambles" the original data into something unreadable.
         *
         * The key idea:
         *   XOR is reversible:
         *     A ^ B ^ B = A
         *
         * If code XOR's the encrypted data with the same key again,
         * it can get the original data back; the same function can
         * be used for both encryption and decryption.
         *
         * key[i % key_length]:
         *   This allows the key to repeat if it is shorter than the source.
         *   Otherwise, would run out of key characters.
         *
         * Algorithm/code based on example from
         * programmingalgorithms.com/algorithm/xor-encryption/cpp/
         */
        output[i] = source[i] ^ key[i % key_length];
    }

    // Output length should always match input length
    assert(output.length() == source_length);

    return output;
}

std::string read_file(const std::string& filename)
{
    // Open the file for reading.
    std::ifstream input_file(filename, std::ios::binary);

    // If the file cannot be opened, return an empty string.
    if (!input_file.is_open())
    {
        std::cerr << "Error: could not open input file: " << filename << std::endl;
        return "";
    }

    // Read the entire file into a string stream, then convert to std::string.
    std::ostringstream buffer;
    buffer << input_file.rdbuf();

    return buffer.str();
}

std::string get_student_name(const std::string& string_data)
{
    std::string student_name;

    // find the first newline
    size_t pos = string_data.find('\n');
    // did we find a newline
    if (pos != std::string::npos)
    { // we did, so copy that substring as the student name
        student_name = string_data.substr(0, pos);
    }

    return student_name;
}

void save_data_file(const std::string& filename, const std::string& student_name, const std::string& key, const std::string& data)
{
    // Open the output file for writing.
    std::ofstream output_file(filename, std::ios::binary);

    if (!output_file.is_open())
    {
        std::cerr << "Error: could not create output file: " << filename << std::endl;
        return;
    }

    // Get the current date so it can be saved in yyyy-mm-dd format.

    // Uses localtime_s to safely convert system time to local date
    // based on Microsoft C++ documentation

    std::time_t now = std::time(nullptr);
    std::tm local_time{};
    localtime_s(&local_time, &now);

    // Save the file in the required assignment format:
    // Line 1: student name
    // Line 2: timestamp
    // Line 3: key used
    // Line 4+: encrypted or decrypted data
    output_file << student_name << '\n';
    output_file << std::put_time(&local_time, "%Y-%m-%d") << '\n';
    output_file << key << '\n';
    output_file << data;
}

int main()
{
    std::cout << "Encyption Decryption Test!" << std::endl;

    // input file format
    // Line 1: <students name>
    // Line 2: <Lorem Ipsum Generator website used>
    // Lines 3+: <lorem ipsum generated with 3 paragraphs> 

    const std::string file_name = "inputdatafile.txt";
    const std::string encrypted_file_name = "encrypteddatafile.txt";
    const std::string decrypted_file_name = "decrypteddatafile.txt";
    const std::string source_string = read_file(file_name);
    const std::string key = "My!Secur3key123";

    // Stop early if the file could not be read.
    if (source_string.empty())
    {
        std::cerr << "Error: input file was empty or could not be read." << std::endl;
        return 1;
    }

    // get the student name from the data file
    const std::string student_name = get_student_name(source_string);

    // encrypt sourceString with key
    const std::string encrypted_string = encrypt_decrypt(source_string, key);

    // save encrypted_string to file
    save_data_file(encrypted_file_name, student_name, key, encrypted_string);

    // decrypt encryptedString with key
    const std::string decrypted_string = encrypt_decrypt(encrypted_string, key);

    // save decrypted_string to file
    save_data_file(decrypted_file_name, student_name, key, decrypted_string);

    std::cout << "Read File: " << file_name << " - Encrypted To: " << encrypted_file_name << " - Decrypted To: " << decrypted_file_name << std::endl;

    // students submit input file, encrypted file, decrypted file, source code file, and key used
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
